var content = [];

//when document is ready
$(document).ready(pageReady);

//page ready
function pageReady() {
    $("#planning").addClass("w3-green");
    $("#layout").addClass("w3-green");
}
